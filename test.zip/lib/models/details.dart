class DetailsModel {
   final String title;
   final String descrption;
 

  DetailsModel(
    this.title,
    this.descrption,
    
  );

}
