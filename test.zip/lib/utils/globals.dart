//library jewel_today.globals;

import 'package:ui_test/models/NewsPost.dart';


String newslanguage = "English";
List<NewsArticle> newsArticles = List<NewsArticle>();
List<String> tabcategory = new List();
List<NewsArticle> trendingNews = List<NewsArticle>();
bool islidershow = false;
final
//String font_news="Titillium Web";
    String font_news = "Varela Round";

List<String> categories = [
  "SPORTS",
];

int selectedLanguageIndex = 0;

// getValue(String key) async {
//   return await storage.read(key: key);
// }

// writeValue(String key, String value) async {
//   return await storage.write(key: key, value: value);
// }
