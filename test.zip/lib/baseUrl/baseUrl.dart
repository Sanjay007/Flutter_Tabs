class BaseURL{


 
static final BASE_URL = "https://quicknews360.com/api/";
//static final BASE_URL = "https://news-mag.herokuapp.com/api/";
  
  
//static final BASE_URL = "http://192.168.1.179:7000/api/";

//static final BASE_URL = "http://192.168.1.162:7000/api/"; //belal

     






    
    
    
}