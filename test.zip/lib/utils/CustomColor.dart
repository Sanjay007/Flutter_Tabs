import 'package:flutter/material.dart';

class Customcolor {
  static Color splashscreencolor =  Color(0xFF03A8D4);
  static Color textfieldbgcolor =  Color.fromRGBO(255,255,255,0.2);
  static Color buttondbgcolor =  Colors.pink;
  static Color testcolor =  Color(0xFF89ED91);

}