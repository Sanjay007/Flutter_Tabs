class Customstring {
 

}